# Scoring a goal from corner

## What is tested

- When a robot scores an own goal directly from a corner kick, a corner kick is
  awarded to the opponent team.

## Setup

- A corner is awarded to team BLUE

## Description

1. BLUE 1 kicks the ball directly into its own goal.
2. No goal is scored and a corner kick is awarded to team RED.
