# Knock-out game: simple win

This test has to be performed manually for now.

## What is tested

If at the end of the regular time of a knockout game a team has scored more
goals than the other, then it is announced as winner and the game ends.

## Description

1. Team RED score a goal during the first half.
2. Game time passes until the end.
3. At the end of second half, AutoRef declares team red winner of the match.
4. The simulation closes automatically afterwards.
