# Scoring own goal

## What is tested

A robot from team RED kicks over blue goal, the result should be a goal kick for
BLUE team starting at the appropriate location.

## Setup

- Only robot RED 1 is used.

## Description

1. RED 1 kicks the ball after PLAYING signal and moves it out of the center
   circle
2. RED 1 kicks the ball again above the goal. 
3. A goal kick is given to team BLUE
