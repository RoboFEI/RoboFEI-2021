# Scoring a goal from corner

## What is tested

- When a robot scores a goal directly from a corner kick it is considered as valid

## Setup

- A corner is awarded to team BLUE

## Description

1. BLUE 1 kicks the ball directly into the opponent goal.
2. A goal is awarded to team BLUE and a kick-off is awarded to team RED.
