# Scoring an own goal from goal kick

## What is tested

- When a robot scores an own goal directly from a goal kick, a corner kick is
  awarded to the opponent team.

## Setup

- A goal-kick is awarded to team BLUE

## Description

1. BLUE 1 kicks the ball directly into its own goal.
2. A corner kick is awarded to team RED
