# Kick-off - scenario 3

## What is tested

If the robot performing free-kick touches again the ball out of the center
circle, then the goal is valid

## Setup

- Team BLUE has Kick-off
- Only one robot is used

## Description

1. BLUE 2 touches the ball after PLAYING, ball moves outside the center circle
2. BLUE 2 moves out of center circle
3. BLUE 2 kicks the ball in the goal
4. A goal is scored
