# Misc - High entry

This test checks that if a robot enters the game or re-enters the game high
above the ground, the referee does not crash.
